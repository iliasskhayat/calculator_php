<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="calcul.css">
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale">
<title> page web  19 dec </title>
    </head>

    <body >
       
        <div> 
            <form  action="19deccalcul.php"  mathod="GET">
              <table  align="center" border="20">
                  <tr>
                      <th colspan="2">CALCULATOR </th>
                  </tr>
                <!-- <caption> CALCULATRICE </caption> -->
                <tr> 
                    <td class="num"> <input   type="number" name="num1" placeholder="numero 1"
                     value="<?php $var1=$_GET["num1"] ;
                              if($var1)
                              echo $var1;
                              else
                              echo ' ';
                              ?>">
                    </td>
                   
                  
                    <td class="num"> <input   type="number" name="num2" placeholder="numero 2"
                    value="<?php $var2=$_GET["num2"] ;
                              if(!$var2)
                              echo $var2;
                              else
                              echo ' ';
                              ?>"
                    
                    >
                    </td> 
                     
                </tr>
           
                  <th colspan="2"> <i> <b>choisir une opération</b> </i> </th> 
                  <tr>
                       <td> <b size="40px"> <input type="radio" name="operation" value="1"> + </b> </td>
                       <td> <b size="40px"> <input type="radio" name="operation" value="2"> - </b> </td>
                  </tr>

                   <tr>
                       <td> <b size="40px"> <input type="radio" name="operation" value="3"> * </b>  </td>
                       <td> <b size="40px"><input type="radio" name="operation" value="4"> / </b>  </td>
                  </tr>

               
              </table>
     <div   align="center"> <input  type="submit" value="calculer"></div>
        </form>

       <table  align="center" border="2">
           <tr> 
               <td class="cas1"> <b>RESULTAT</b></td>
               <td class="cas2">   
          
                <?php
                if(isset($_GET["num1"]))
                  {
                      $n1= ($_GET["num1"]);
                      $n2=($_GET["num2"]); 
                      if(isset($_GET["operation"])){

                     
                      $op=$_GET["operation"];

                   switch($op){
                       case "1":$res=$n1+$n2;
                           echo $res;
                           break;
                       case "2":$res=$n1-$n2;
                           echo $res;
                           break;
                       case "3":$res=$n1*$n2;
                           echo $res;
                           break;
                       case "4":
                          if($n2==0)
                              {
                               echo "fatal erreur!!! division par 0"  ;
                              }
                           else{
                             $res=$n1/$n2;
                              echo $res;
                              break;  
                    }} }}
?>
               </td>
           </tr>
       </table>
     
        </div>


    </body>
    </html>